# Agenda 11 – Desenvolvimento de Sistemas I

**Aluna:** Emily Eduarda Lacerda dos Santos  
**Atividade:** Controle de Níveis de Água

## Objetivo

Desenvolver um programa simples em Python que simula o monitoramento de um reservatório de água. O programa mostra cinco níveis diferentes, cada um com uma mensagem e uma cor no terminal.

## Níveis do reservatório

| Nível | Situação | Cor |
|---|---|---|
| 1 | Muito baixo (crítico) | Vermelho |
| 2 | Baixo | Amarelo |
| 3 | Médio | Verde |
| 4 | Alto | Ciano |
| 5 | Muito alto (alerta) | Azul |

## Como executar

É necessário ter o Python instalado. No terminal, dentro da pasta do projeto, execute:

```bash
python -m pip install -r requirements.txt
python main.py
```

Em alguns computadores, pode ser necessário usar `python3` no lugar de `python`.

## Como o código funciona

- A lista `situacoes` guarda as mensagens dos cinco níveis.
- A função `definir_cor(nivel)` escolhe a cor correspondente usando a biblioteca `colorama`.
- A função `mostrar_situacao(nivel)` apresenta a mensagem colorida e restaura o estilo padrão do terminal.
- A função `main()` percorre os cinco níveis para simular o monitoramento, sem solicitar dados ao usuário.
- Os níveis inválidos são identificados com uma mensagem de erro por meio de `ValueError`.

## Exemplo de saída

```text
=== CONTROLE DE NÍVEIS DE ÁGUA ===
Simulação do monitoramento do reservatório:

Nível 1: Muito baixo (crítico)
Nível 2: Baixo
Nível 3: Médio
Nível 4: Alto
Nível 5: Muito alto (alerta)

Simulação finalizada.
```

**Observação:** ao executar no terminal, cada nível aparece na cor correspondente.

## Competência e habilidades trabalhadas

**Competência 4:** Elaborar sistemas aplicando princípios e paradigmas de programação.

**Habilidade 4.1:** Codificar programas, utilizando técnica de programação estruturada.

**Habilidade 4.2:** Depurar e versionar programas, utilizando ambiente de desenvolvimento integrado.

## Arquivos do projeto

- `main.py`: código da simulação.
- `requirements.txt`: dependência necessária para executar o programa.
- `README.md`: explicação e instruções do projeto.

## Entrega

O projeto deve ser publicado em um repositório do GitHub. O link do repositório deve ser enviado no ambiente virtual da ETEC.
